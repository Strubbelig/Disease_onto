# Disease Ontology Artifact-Evaluation Release Candidate

Generated: 2026-08-10T19:46:06-04:00

This package is generated from `data/disease_terms_review_enriched.csv`, the sole editable master table.

## Contents

- `ontology/disease_terms_review.ttl`: all 276 screening/evidence records.
- `ontology/disease_terms_synthesis.ttl`: included-only synthesis view.
- `ontology/review_core.ttl`: review annotation-property declarations.
- `ontology/native_hierarchy_modules/`: subject-sanitized native evidence modules.
- `ontology/catalog-v001.xml`: local UUID-URN import resolution.
- `audit/`: schema, data dictionary, changelog, and readiness report.
- `figures/`: ontology-artifact selection flow in PNG and SVG formats.
- `docs/Disease_Ontology_Artifact_Evaluation_Manuscript.md`: JAMIA Open Research and Applications draft.
- `docs/OSF_Retrospective_Registration_Addendum.md`: correction record for the retrospective OSF registration.
- `docs/second_reviewer_stratified_validation.md`: independent validation protocol.

## Current Decision State

- Included: 145
- Excluded: 131
- Needs adjudication: 0

This is a release candidate, not the final scholarly release. Remaining eligibility or citation decisions are reported in the audit. Independent stratified validation, OSF correction metadata, authorship and disclosure metadata, and reference reconciliation remain author tasks. The evidence ontology uses non-resolving UUID URNs and is intended to travel with the publication as a self-contained supplement. A broader philosophical-literature synthesis is a separate project and is not part of this artifact-evaluation denominator.

The package is MIT-licensed as specified in `LICENSE`. Extracted source-ontology statements retain their original provenance and any rights held by their source publishers.
