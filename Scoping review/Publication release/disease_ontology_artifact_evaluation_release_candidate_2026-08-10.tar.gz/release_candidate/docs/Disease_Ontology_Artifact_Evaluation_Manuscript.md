# How Is Disease Formally Modelled in Biomedical Ontologies? A Systematic Cross-Sectional Evaluation of Public Ontology Artifacts

**Moritz Milewski, MD^1,2 and Martin Boeker, MD, MME, MCSc^3**

1. Section of Plastic and Reconstructive Surgery, Department of Surgery, Yale School of Medicine, New Haven, Connecticut, USA  
2. Department of Plastic, Aesthetic, Hand and Reconstructive Surgery, Hannover Medical School, Hannover, Germany  
3. Chair of Medical Informatics, Technical University of Munich, Munich, Germany

**Positions:** Moritz Milewski, MD, is a Postdoctoral Research Fellow in Plastic and Reconstructive Surgery at Yale School of Medicine and a resident in Plastic Surgery at Hannover Medical School. Martin Boeker, MD, MME, MCSc, is a Full Professor at the Technical University of Munich.  
**Corresponding author:** Moritz Milewski, MD, Yale School of Medicine, 333 Cedar Street, New Haven, CT 06510, USA; telephone: +1 203-392-4520; email: moritz.milewski@yale.edu; alternate email: milewski.moritz@mh-hannover.de  
**ORCID:** Moritz Milewski, 0009-0006-6251-7592; Martin Boeker, 0000-0003-2972-2042  
**Keywords:** disease; biomedical ontology; knowledge representation; ontology evaluation; semantic interoperability

*Target article type: JAMIA Open, Research and Applications. Draft v0.6, 10 August 2026. The study analyses primary digital artifacts and is not a scoping or systematic review of secondary literature. Citations remain in author-year form during drafting and will be converted in Zotero to the journal's numbered style before submission.*

> ## Outstanding work before submission
>
> 1. Resolve the three records still marked `needs_user_decision` (MEDICALINFO, OFDSIPT, and PATEL) and the three unreviewed citation-status records (MSCDO, DRANPTO, and ONVOC).
> 2. Complete the prespecified independent 50-class stratified validation, retain both assessors' original codes, reconcile disagreements, and insert agreement results.
> 3. Add the OSF registration date and identifier. When the embargo ends, publish a dated correction/addendum explaining the change from the submitted “scoping review” label to an empirical artifact evaluation.
> 4. Confirm both authors' competing interests and the institutional route for article-processing-charge coverage.
> 5. Reconcile the reference inventory in Zotero and convert it to JAMIA Open style.
> 6. Freeze the master CSV, regenerate the supplementary TTL files and Figure 1, rerun all checks, and rebuild the release archive.

## Abstract

### Objectives

To determine how publicly accessible biomedical ontologies formally represent disease and closely related classes, assess the explicitness and quality of their ontological grounding, and identify implications for semantic interoperability.

### Materials and Methods

We performed a systematic cross-sectional evaluation of ontology artifacts retrieved from BioPortal, the Ontology Lookup Service, the OBO Foundry, and targeted source repositories between 29 June and 6 July 2026. The primary unit was a unique OWL/RDFS class IRI, not a publication. Exact-label and sensitivity searches identified disease, disorder, condition, syndrome, pathological-process, and related candidates. Source appearances were merged by IRI. Automated routing removed out-of-scope, duplicate-imported, and superseded candidates; a human assessor evaluated retained classes using labels, definitions, comments, mappings, provenance, and asserted superclass hierarchies. Controlled variables captured ontological category, grounding of pathologicality, treatment of gradedness, reality-versus-classification commitments, and entity quality. Publications were used only as ancillary provenance or interpretive evidence. A second assessor will independently validate a prespecified stratified sample before submission.

### Results

The master dataset contains 278 unique class IRIs. At the current checkpoint, 146 classes are included, 129 excluded, and three await eligibility decisions. Among provisionally included classes, 100/146 (68%) had no identifiable disease model. Twenty-four followed a disposition, realizable-entity, or dependent-continuant route and eight represented disease as a process. Pathologicality was undefined in 111/146 classes, and every class was silent about crisp versus graded membership. Only 11/146 definitions were rated good. BFO-aligned continuant classes had better parentage and higher entity-quality scores than ungrounded classes, although these comparisons are descriptive and partly reflect the evaluation rubric.

### Discussion

Disease labels are widespread, but explicit models of what a disease is are uncommon. The few grounded implementations concentrate around BFO and the OGMS disposition pattern, while many resources depend on OGMS, DOID, or MONDO rather than defining an independent model. Shared labels therefore provide weak evidence of semantic compatibility. Registry coverage, annotation completeness, and interpretive single-assessor coding limit the findings.

### Conclusion

Biomedical ontology developers should reuse and explicitly cite a grounded disease pattern or document an intentional alternative. A bare `Disease` class is insufficient for reliable integration even when its label or mappings agree with other resources.

## Lay Summary

Biomedical databases often use ontology classes called “disease,” “disorder,” or “condition” to combine information from different sources. The same label does not guarantee that these classes mean the same kind of thing. We systematically inspected publicly available ontology classes and assessed their definitions, explanatory comments, and position in the class hierarchy. Most classes did not state whether a disease is a persistent property of a person, a process unfolding over time, a biological state, or merely a classification label. Explicitly grounded classes most often followed the Basic Formal Ontology and Ontology for General Medical Science pattern, in which a disease is a disposition grounded in a bodily disorder and realized through pathological processes. These classes were generally easier to interpret than classes without an identifiable upper-level model. Our dataset records both the retrieved evidence and the assessment for every class. It can help ontology developers and health-data integrators identify when apparently equivalent disease labels conceal incompatible meanings.

## Background and Significance

Biomedical ontologies use classes such as *disease*, *disorder*, and *condition* to integrate clinical, research, and molecular data. Their labels can conceal materially different ontological commitments. A disease may be represented as a disposition borne by an organism, a process unfolding over time, a state or quality, a structural disorder, a clinical finding, or a classification category with no stated commitment. These choices determine whether disease instances persist or occur, how they relate to signs and diagnoses, and whether classes with similar labels can be safely aligned.

The Ontology for General Medical Science (OGMS) models disease as a disposition to undergo pathological processes because of a material disorder (Scheuermann et al., 2009). This supports presymptomatic disease and separates disease from its realization, but it does not itself explain what makes a process pathological. Process-centred proposals instead represent disease through pathological events or causal chains (Mizoguchi et al., 2011). BioTop deliberately permits an under-committed “condition” pattern (Schulz et al., 2011), while pragmatic disease resources such as DOID and MONDO prioritize classification and integration. These approaches are not interchangeable, yet ontology reuse and mapping can make them appear equivalent.

Four questions expose the principal commitments. First, is disease a continuant, an occurrent, a deliberate mixture, or unspecified? Second, is pathologicality grounded statistically, evolutionarily, normatively, through explicit primitive criteria, or left undefined? Third, is class membership explicitly crisp, graded, prototype-based, or delegated to data? Fourth, does the class denote an underlying biological entity, an illness role, a nosological category, a precision-medicine stratification, or a conflation of these? Published proposals discuss particular answers, but they do not establish how classes available to contemporary ontology users are actually implemented.

This study therefore treats ontology classes themselves as primary data. It is a systematic, cross-sectional artifact evaluation rather than a synthesis of published studies. The objective was to enumerate retrievable disease-class candidates, evaluate their explicit modelling commitments and evidence quality, and describe consequences for reuse and interoperability.

## Materials and Methods

### Study Design and Data Sources

We conducted a systematic cross-sectional evaluation of machine-readable ontology artifacts. BioPortal was the primary sampling frame; the EBI Ontology Lookup Service (OLS) and active OBO Foundry products provided supplementary coverage. Targeted GitHub or ontology-site retrieval was used only to resolve known artifacts or replacement classes. Searches and retrieval occurred from 29 June through 6 July 2026. Registry timestamps, URLs, ontology identifiers, and available version metadata were retained.

The primary observational unit was one OWL/RDFS class identified by IRI together with its retrievable labels, definitions, comments, synonyms, asserted named superclasses, mappings, and source metadata. One class appearing in several registries or importing ontologies was represented once in the analytical table, while all source appearances were retained as provenance. Publications linked to an ontology were ancillary evidence; they were neither sampling units nor independently screened study records.

The protocol was submitted retrospectively to OSF Registries under embargo using a generalized systematic-review form (**identifier and registration date to add**). Because the submitted record described the project as a scoping review, a dated correction will accompany the public record. This manuscript reports the implemented design as an empirical artifact evaluation and does not claim prospective registration.

### Candidate Ascertainment

BioPortal and OLS APIs were queried using normalized exact-label matches. Active OBO Foundry products not represented in BioPortal were scanned directly. Primary terms were `disease`, `disorder`, `illness`, `condition`, `health condition`, `syndrome`, `pathological process`, `pathological disposition`, and `dysfunction`, including documented capitalization and compound-label variants. Sensitivity terms covered pathological or abnormal states, morbid condition, nosological entity, and limited French and German equivalents. Full endpoints, parameters, terms, and pagination rules are provided in Supplementary Methods S1.

Automated routing removed value-set collections, concepts outside the disease-model scope, imported appearances without independent modelling, explicit exact matches to canonical roots, and weaker same-ontology candidates. A syndrome or pathological-process hit was suppressed when the ontology exposed a more direct disease/disorder target, unless the process was itself the ontology's disease model. Local or WebProtege IRIs and sparse annotation were treated as quality concerns rather than automatic exclusions. Exact IRI was the deduplication key.

### Eligibility and Assessment

A class was eligible when it represented disease or a justified immediate conceptual neighbour and exposed sufficient artifact or registry evidence to assess at least its identity and asserted placement. Thesauri, value sets, demo resources, out-of-scope concepts, mapping-only appearances, and unmodified imported duplicates were retained in the screening record but excluded from independent synthesis. Reused classes remained eligible when the receiving ontology's placement or adaptation constituted an independent modelling decision.

One assessor examined each candidate in an interactive interface and, where necessary, in generated hierarchy modules or the source artifact. Controlled fields recorded provenance, eligibility, native/imported status, ontology type, ontological category, pathological grounding, crisp-versus-graded commitment, reality-versus-classification commitment, logical inconsistency, and a modelling comment. Definition, comment, and parentage quality were rated separately. Entity quality ranged from 0 (excluded) to 3 (good definition and superclass placement with explicit grounding). Rule-based prefills were restricted to explicit evidence patterns and remained open to human confirmation.

A second assessor will independently code a prespecified stratified sample of 50 unique IRIs while blinded to the first assessor's decisions. Raw agreement will be reported for every controlled field, Cohen's kappa for eligible nominal variables, and weighted kappa for entity-quality score. Both original assessments and the adjudicated value will be preserved.

### Analysis and Reproducibility

Counts and percentages describe eligibility, model categories, design commitments, and annotation quality. Means summarize entity-quality scores for selected model families. These are descriptive artifact-level comparisons, not causal estimates. The quality rubric includes explicit grounding and relevant parentage; comparisons involving those features are therefore partly criterion-dependent. No meta-analysis or risk-of-bias-across-studies assessment was performed because the observations are ontology classes.

The sole editable master is `disease_terms_review_enriched.csv`. Deterministic scripts generate a complete evidence ontology, an included-only synthesis ontology, source hierarchy modules, an audit report, and Figure 1. The supplementary package uses fixed non-resolving UUID URNs and a local XML catalog. Search credentials are excluded.

## Results

### Artifact Selection

Registry searching, targeted retrieval, deterministic routing, and exact-IRI deduplication produced 278 unique class records from 160 recorded ontology identifiers. At the current checkpoint, 146 are included, 129 excluded, and three require substantive eligibility decisions. Registry appearances are retained as provenance but are not added as independent observations because routing and exclusion logs deliberately overlap. Final counts and Figure 1 will be regenerated after the outstanding decisions and independent validation.

![Figure 1. Flow of ontology source appearances and unique class IRIs through automated routing, deduplication, and human eligibility assessment.](Figures/artifact_selection_flow_diagram.png)

**Figure 1. Ontology-artifact selection flow.** An appearance is one class in one registry/source-ontology context; a class is a unique IRI after deduplication. Dependency-only appearances are analysed at their native provider rather than counted as independent disease models.

### Disease Models and Grounding

The dominant result was absence of explicit grounding. Among 146 provisionally included classes, 100 (68%) were assigned `no_grounded_model`. Twenty-four classes formed the BFO-aligned disposition/realizable-entity/dependent-continuant family, and eight represented a process or course of events. Other categories were uncommon: three Kantian-state classes, three BioTop-style conditions, two quality models, one mixed model, one disorder model, and four unclear classes.

| Disease-model category | Classes |
|---|---:|
| No identifiable grounded model | 100 |
| Disposition, realizable entity, or dependent continuant | 24 |
| Process or course of events | 8 |
| State, BioTop condition, or quality | 8 |
| Mixed or disorder model | 2 |
| Unclear | 4 |

Pathological grounding was undefined in 111/146 classes. Sixteen used explicit primitive criteria, 11 referred to evolutionary function, four were normative, three were statistical, and one was not applicable. All 146 classes were coded silent on crisp versus graded membership: OWL representation alone was not treated as an explicit philosophical commitment.

### Annotation and Entity Quality

Definition quality was absent for 69 classes, partial for 51, poor for 15, and good for 11. Parentage was poor or absent for 108 classes. Entity-quality scores were 1 for 122 classes, 2 for 22, and 3 for two.

The 24 BFO-aligned continuant classes had a mean entity-quality score of 1.92/3; 19 (79%) had good parentage. All 100 ungrounded classes scored 1/3, and 97 had poor or absent parentage. Good definitions occurred in 4/24 BFO-aligned classes and 5/100 ungrounded classes. This association does not establish that adopting BFO causes higher quality because grounding and parentage contribute to the rubric. It does show that the BFO/OGMS pattern makes category and placement more inspectable. Eleven of the 24 BFO-aligned classes still did not define pathologicality.

### Reuse and Foundational Ontologies

Dependency appearances concentrated on OGMS, DOID, MONDO, and the UMLS Semantic Type network. The landscape therefore depends on a small set of reference resources even though many consuming ontologies expose their own disease labels. BFO, usually through OGMS, was the dominant explicit foundational commitment. BioTop and SIO accounted for small condition- and quality-oriented groups. No eligible class in the retrieved artifact set committed to DOLCE, GFO, or YAMATO.

The Hozo River Flow Model was not indexed in BioPortal, OLS, or the OBO Foundry, and links inspected on the ontology laboratory website did not resolve to a downloadable artifact (Mizoguchi et al., 2011). YAMATO was likewise unavailable as an inspectable artifact (Mizoguchi et al., 2022). Their absence from the denominator reflects availability, not a negative evaluation.

## Discussion

The principal finding is that biomedical ontologies much more often label disease than model it. Nearly seven in ten included classes conveyed no identifiable account of what kind of entity a disease is. Explicit implementations were concentrated around the BFO/OGMS disposition pattern, with process, state, quality, and deliberately mixed alternatives forming a small minority. Definitions rarely supplied what hierarchy omitted: only 8% were rated good, and pathologicality was usually undefined.

This matters for interoperability. An exact label or mapping can connect a disposition, a process, a finding, and a nosological category while concealing category incompatibility. Conversely, importing a reference class can provide a shared model without creating another independent implementation. Integration workflows should therefore inspect provenance, upper-level placement, and defining axioms rather than infer semantic equivalence from lexical agreement.

### Suitability of Foundational Frameworks

| Framework | Support and enforcement | Limitation observed here |
|---|---|---|
| **BFO with OGMS** | Separates continuants from occurrents and relates disease disposition, material disorder, and pathological realization. It most strongly exposes category errors. | BFO alone does not define pathologicality; the disease-level OGMS pattern is essential. |
| **BFO process route** | Gives clear occurrent placement for pathways or pathological processes. | Can collapse disease into manifestation or course unless bearer and disposition are represented separately. |
| **BioTop condition pattern** | Supports deliberate under-commitment across state, quality, and process perspectives. | Its flexibility provides less enforcement of a single disease category. |
| **SIO quality route** | Connects disease-related qualities to measurements and data. | Generic quality semantics do not supply a disease-specific causal theory. |
| **YAMATO/River Flow Model** | Publications describe diachronic causal organization across states and processes. | Artifact-level implementation could not be assessed. |
| **No identifiable top ontology** | Permits local modelling freedom. | Supplies no shared constraint for detecting cross-ontology category incompatibility. |

For interoperable disease-class modelling, the evidence favours BFO plus an explicit disease-level pattern such as OGMS over either bare BFO import or an unanchored disease class. BioTop is suitable when under-commitment is intentional and documented; SIO is useful for measurement-centred representations. No top ontology by itself determines what counts as pathological.

### Limitations

The sampling frame was limited to classes discoverable through selected registries, normalized labels, and targeted retrieval. Unindexed, idiosyncratically labelled, non-English, or inaccessible artifacts may be absent. APIs and extracted modules may omit annotations, anonymous restrictions, or imported axioms. Interpretation of definitions and hierarchy required human judgement; one assessor completed the full dataset, with only a stratified independent validation planned. Counts are a snapshot of recorded versions retrieved from 29 June through 6 July 2026. The quality comparison is partly criterion-dependent. Finally, unavailable River Flow/YAMATO artifacts prevented empirical comparison of those approaches.

## Conclusion

Public biomedical ontologies commonly provide a disease label without an explicit disease model. A small BFO/OGMS-aligned minority is more inspectably grounded, but even those classes often leave pathologicality undefined. Ontology developers should reuse and cite a coherent reference pattern or document why an alternative category is intended. Data integrators should treat lexical agreement among disease, disorder, and condition classes as a prompt for ontological inspection rather than evidence of equivalence.

## Funding

No dedicated external funding supported this study. Funding for individual ontology projects was not systematically available from artifact metadata and was not analysed.

Article processing charges, if incurred, are expected to be covered through an institutional open-access agreement or publication fund, subject to confirmation. Such administrative publication support would not constitute funding of the research.

## Ethics Approval

The study used publicly accessible digital artifacts and bibliographic metadata and involved no human participants, patient data, or animal research. Institutional ethics approval and consent were not required.

## Competing Interests

**[Both authors to confirm.]** The authors declare no competing interests.

## Author Contributions

Moritz Milewski: Conceptualization; Data curation; Formal analysis; Investigation; Methodology; Project administration; Software; Visualization; Writing - original draft; Writing - review and editing. Martin Boeker: Supervision; Writing - review and editing. Proofreading is included under Writing - review and editing. Add Validation to the appropriate author only after completion of the independent stratified assessment.

## Acknowledgements and Generative AI Disclosure

A generative AI coding assistant supported script development, deterministic transformations, quality-control checks, and language editing. It did not autonomously determine eligibility or final interpretive codes and does not qualify as an author. The authors take responsibility for all decisions and claims. **[Confirm against JAMIA Open's disclosure requirements at submission.]**

## Data and Code Availability

Supplementary Table S1 (`disease_terms_review_enriched.csv`) is the complete class-level record. Supplementary Data S2 (`disease_terms_review.ttl`) contains all evidence and assessment records; Supplementary Data S3 (`disease_terms_synthesis.ttl`) contains the included analytical subset. Source modules, scripts, schema, data dictionary, audit report, and release manifest accompany the publication. The UUID-URN ontology package is self-contained and is not maintained as a public web ontology. The BioPortal API key is not distributed.

## References

*Draft inventory for Zotero reconciliation. Convert to JAMIA Open's numbered style before submission.*

Arp, R., Smith, B., & Spear, A. D. (2015). *Building ontologies with Basic Formal Ontology*. MIT Press.

Boorse, C. (1977). Health as a theoretical concept. *Philosophy of Science, 44*(4), 542-573. https://doi.org/10.1086/288768

Ceusters, W., & Smith, B. (2010). Foundations for a realist ontology of mental disease. *Journal of Biomedical Semantics, 1*, 10. https://doi.org/10.1186/2041-1480-1-10

Engelhardt, H. T., Jr. (1975). The concepts of health and disease. In H. T. Engelhardt Jr. & S. F. Spicker (Eds.), *Evaluation and explanation in the biomedical sciences* (pp. 125-141). Reidel. https://doi.org/10.1007/978-94-010-1769-5_9

Ereshefsky, M. (2009). Defining health and disease. *Studies in History and Philosophy of Biological and Biomedical Sciences, 40*(3), 221-227. **[Verify in Zotero.]**

Goldfain, A., Smith, B., & Cowell, L. G. (2010). Dispositions and the Infectious Disease Ontology. In *Formal Ontology in Information Systems: Proceedings of FOIS 2010* (pp. 400-413). IOS Press. https://doi.org/10.3233/978-1-60750-535-8-400

Haendel, M. A., McMurry, J. A., Relevo, R., Mungall, C. J., Robinson, P. N., & Chute, C. G. (2018). A census of disease ontologies. *Annual Review of Biomedical Data Science, 1*, 305-331. https://doi.org/10.1146/annurev-biodatasci-080917-013459

Hucklenbroich, P. (2014). Disease entity as the key theoretical concept of medicine. *Journal of Medicine and Philosophy, 39*(6), 609-633. https://doi.org/10.1093/jmp/jhu040

Jansen, L. (2007). Tendencies and other realizables in medical information sciences. *The Monist, 90*(4), 534-554. https://doi.org/10.5840/monist200790436

Mizoguchi, R., Kozaki, K., Kou, H., Yamagata, Y., Imai, T., & Ohe, K. (2011). River Flow Model of diseases. In *Proceedings of the International Conference on Biomedical Ontology 2011* (pp. 63-70). **[Verify in Zotero.]**

Mizoguchi, R., & Borgo, S. (2022). YAMATO: Yet-another more advanced top-level ontology. *Applied Ontology, 17*(1), 211-232. https://doi.org/10.3233/AO-210257

Rohl, J., & Jansen, L. (2014). Why functions are not special dispositions: An improved classification of realizables for top-level ontologies. *Journal of Biomedical Semantics, 5*, 27. https://doi.org/10.1186/2041-1480-5-27

Rovetto, R. J., & Mizoguchi, R. (2015). Causality and the ontology of disease. *Applied Ontology, 10*(2). https://doi.org/10.3233/AO-150147 **[Add pages from Zotero.]**

Sadegh-Zadeh, K. (2000). Fuzzy health, illness, and disease. *Journal of Medicine and Philosophy, 25*(5), 605-638. https://doi.org/10.1076/0360-5310(200010)25:5;1-W;FT605

Scheuermann, R. H., Ceusters, W., & Smith, B. (2009). Toward an ontological treatment of disease and diagnosis. *Summit on Translational Bioinformatics*, 116-120. PMCID: PMC3041577.

Schriml, L. M., et al. (2022). The Human Disease Ontology 2022 update. *Nucleic Acids Research, 50*(D1), D1255-D1261. https://doi.org/10.1093/nar/gkab1063

Schulz, S., Spackman, K., James, A., Cocos, C., & Boeker, M. (2011). Scalable representations of diseases in biomedical ontologies. *Journal of Biomedical Semantics, 2*(Suppl 2), S6. https://doi.org/10.1186/2041-1480-2-S2-S6

Vasilevsky, N. A., et al. (2022). Mondo: Unifying diseases for the world, by the world. *medRxiv*. https://doi.org/10.1101/2022.04.13.22273750 **[Check for a peer-reviewed replacement in Zotero.]**

Wakefield, J. C. (1992). The concept of mental disorder: On the boundary between biological facts and social values. *American Psychologist, 47*(3), 373-388. https://doi.org/10.1037/0003-066X.47.3.373

## Supplementary Files

- **Figure 1:** `Figures/artifact_selection_flow_diagram.png` and `.svg`.
- **Supplementary Methods S1:** `Workflow instructions/Supplementary_Methods_Ontology_Artifact_Evaluation.md`.
- **Supplementary Table S1:** `Extraction Tables/disease_terms_review_enriched.csv`.
- **Supplementary Data S2:** `Extraction Ontology/disease_terms_review.ttl`.
- **Supplementary Data S3:** `Extraction Ontology/disease_terms_synthesis.ttl`.
- **Supplementary Data S4:** `Extraction Ontology/native_hierarchy_modules/` and its manifest.
- **Supplementary Methods S5:** extraction, figure-generation, publication-readiness, and validation scripts plus the schema, data dictionary, audit report, and release manifest.
