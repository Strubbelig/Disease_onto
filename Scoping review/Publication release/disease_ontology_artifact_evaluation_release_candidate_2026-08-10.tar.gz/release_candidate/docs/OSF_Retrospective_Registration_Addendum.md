# Retrospective Registration Correction and Addendum

## Corrected Study Title

How Is Disease Formally Modelled in Biomedical Ontologies? A Systematic Cross-Sectional Evaluation of Public Ontology Artifacts

## Registration Timing

The registration is retrospective. Ontology retrieval and first-assessor coding began and were substantially completed before registration. It must not be described as a preregistration or prospective protocol. The registration is currently under embargo; add its identifier and registration date here when available.

## Correction of Design Label

The submitted registration used the label “scoping review.” After submission, the investigators recognized that the primary observations were ontology classes rather than published studies. The study is therefore more accurately classified as a **systematic cross-sectional evaluation of primary digital ontology artifacts**.

This correction changes the study label and reporting framework. It does not change the sampling frame, retrieval dates, search terms, eligibility criteria, class-level variables, quality rubric, or descriptive analysis. PRISMA-ScR will not be claimed in the publication. A transparent artifact-selection flow diagram is retained without PRISMA branding.

The original registration should remain preserved. When the embargo ends, attach this dated correction or place equivalent wording in the public project and manuscript rather than silently replacing the submitted record.

## Implemented Scope

The observations are OWL/RDFS classes identified by IRI and retrieved from BioPortal, the EBI Ontology Lookup Service, the OBO Foundry, or targeted artifact retrieval. Each record contains available labels, definitions, comments, synonyms, asserted named superclass hierarchy, mappings, source metadata, and approved supporting citations. Publications provide ancillary provenance or interpretive evidence; they are not independently screened study records. The philosophical-literature synthesis is a separate project.

## Information Sources and Dates

- BioPortal API, primary source: 29 June to 6 July 2026.
- EBI Ontology Lookup Service v4: 29 June to 4 July 2026.
- OBO Foundry registry and direct active-product scan: 29 June 2026.
- Targeted GitHub or ontology-site retrieval for known artifacts or replacement classes, recorded in row-level provenance.

## Unit of Analysis and Deduplication

The unit of analysis is one exact class IRI. Source-ontology and registry appearances were merged by IRI while retaining their provenance. The evaluation does not claim complete extraction of anonymous restrictions or imported logical axioms.

## Selection and Coding

Automated routing addressed source type, term scope, target refinement, semantic equivalence, and imported/reused appearances. One human assessor then evaluated the unique class records using a structured interface. A second assessor will independently code a prespecified stratified sample of 50 classes before submission. Both assessors' original values, agreement statistics, reconciliation decisions, and reasons will be retained.

## Analysis

The analysis uses descriptive counts, percentages, selected group means, a disease-model typology, dependency/reuse summaries, annotation- and entity-quality assessments, and cross-tabulation of ontological category, pathological grounding, crispness/gradedness, and reality/classification. No meta-analysis or risk-of-bias-across-studies assessment is performed because the records are primary ontology artifacts.

## Deviations From the Earlier Draft Protocol

1. The design is reported as a cross-sectional ontology-artifact evaluation rather than a scoping review.
2. The planned bibliographic-database and proceedings synthesis is not part of the artifact denominator and is reserved for a separate project.
3. One assessor coded the full dataset; the second assessor evaluates a stratified sample rather than the complete dataset in duplicate.
4. The completed registry set is BioPortal, OLS, and the OBO Foundry; AberOWL was not searched.
5. Search was implemented as normalized exact-label retrieval with primary, secondary, compound-label, and French/German sensitivity tiers.
6. Provenance and reuse routing was added to distinguish independent implementations from mappings and imported appearances.
7. Evidence was limited to retrievable annotations and asserted named superclass hierarchy rather than complete anonymous and imported axioms.
8. A class-level quality rubric and citation-assignment assessment were added.

## Current Data State

As of 10 August 2026:

- ontology identifiers represented in the master table: 160;
- unique class IRIs in the master table: 278;
- provisionally included: 146;
- excluded: 129;
- eligibility decisions still required: 3;
- included records with citation-status review still required: 3.

These counts are provisional. Replace them with the final machine-generated audit values after the six outstanding decisions and independent validation are complete.

Source appearances remain available in overlapping routing and exclusion audit logs. They are not summed into a single flow denominator because excluded or reused appearances are intentionally retained for provenance and can occur in both logs.

## Files for the Publication Record

- `Scoping_Review_Protocol_Disease_Modelling.md`: historical submitted protocol framing.
- `Reporting_Guideline_Applicability.md`: rationale for the corrected design and reporting approach.
- `Disease_Ontology_Artifact_Evaluation_Manuscript.md`: publication-facing JAMIA Open draft.
- `Supplementary_Methods_Ontology_Artifact_Evaluation.md`: executable methods description.
- `disease_terms_review_enriched.csv`: sole class-level master table.
- `disease_terms_review.ttl` and `disease_terms_synthesis.ttl`: generated evidence and analysis views.
- `artifact_selection_flow_diagram.png`: unbranded artifact-flow diagram.
- dated release archive and manifest.

## Metadata to Complete

- OSF identifier, registration date, public URL, and DOI if assigned.
- Date on which this correction is attached or made public.
- Authors, affiliations, and ORCIDs.
- Funding and conflicts of interest.
- Independent-validation completion date and results.
