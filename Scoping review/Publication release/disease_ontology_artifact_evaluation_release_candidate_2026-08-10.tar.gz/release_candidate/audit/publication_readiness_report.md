# Publication Readiness Report

Generated: `2026-08-10T19:46:06-04:00`

- Master rows: 276
- Unique class IRIs: 276
- Effective status: `{"exclude": 131, "include": 145}`
- Evidence status: `{"fallback_with_evidence": 13, "insufficient_metadata": 6, "native_module": 257}`
- Ambiguous decisions: 0
- Citation assignments still unreviewed: 0
- Approved citations with incomplete core metadata: 0
- Target/module mismatches: 0
- Cross-module duplicate superclass edges: 0

## Ambiguous Decisions

| Ontology | Class | Flags | Manual | Effective | Rule |
|---|---|---|---|---|---|

## Remaining Human Tasks

- When the OSF registration embargo is lifted, insert its public DOI, URL, and registration date in the manuscript.
- Complete and reconcile the prespecified 50-class independent stratified validation sample.
- Confirm both authors' competing interests and the institutional route for article-processing-charge coverage.
- Reconcile the draft reference inventory in Zotero and export it in the selected journal's style.
