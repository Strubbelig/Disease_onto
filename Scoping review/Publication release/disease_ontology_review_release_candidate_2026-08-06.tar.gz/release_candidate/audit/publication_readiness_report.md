# Publication Readiness Report

Generated: `2026-08-06T18:38:33-04:00`

- Master rows: 278
- Unique class IRIs: 278
- Effective status: `{"exclude": 128, "include": 133, "needs_user_decision": 17}`
- Evidence status: `{"fallback_with_evidence": 13, "insufficient_metadata": 6, "native_module": 259}`
- Ambiguous decisions: 77
- Citation assignments still unreviewed: 5
- Approved citations with incomplete core metadata: 0
- Target/module mismatches: 0
- Cross-module duplicate superclass edges: 0

## Ambiguous Decisions

| Ontology | Class | Flags | Manual | Effective | Rule |
|---|---|---|---|---|---|
| NCIT | `http://purl.obolibrary.org/obo/NCIT_C2991` (Disease or Disorder) | eligibility_manual_rule_conflict | include | needs_user_decision | imported_or_reused_term_no_independent_analysis |
| ADHER_INTCARE_EN | `http://www.semanticweb.org/parracarlos/ontologies/2019/3/untitled-ontology-31#Condition` (Condition) | publication_comment_needs_review | include | include | manual_include_status |
| AFO | `http://purl.allotrope.org/ontologies/common#AFC_0000090` (condition) | publication_comment_needs_review | exclude | exclude | manual_include_status |
| AURA | `http://www.projecthalo.com/aura#Condition` (Condition) | publication_comment_needs_review | exclude | exclude | manual_include_status |
| BT-ONTOLOGY | `https://w3id.org/brainteaser/ontology/schema/Condition` (Condition) | eligibility_manual_rule_conflict; citation_approval_unreviewed; publication_comment_needs_review | include | needs_user_decision | defined_by_external_class_no_independent_analysis |
| COCHRANE | `http://data.cochrane.org/ontologies/core/Condition` (Condition) | publication_comment_needs_review | include | include | manual_include_status |
| CSEO | `http://scai.fraunhofer.de/CSEO#Condition` (Condition) | publication_comment_needs_review | exclude | exclude | manual_include_status |
| CTGO | `http://clinicaltrials.gov/ctgo#Condition` (Condition) | publication_comment_needs_review | include | include | manual_include_status |
| NCIT | `http://purl.obolibrary.org/obo/NCIT_C25457` (condition) | eligibility_manual_rule_conflict | include | needs_user_decision | imported_or_reused_term_no_independent_analysis |
| IDOMAL | `http://purl.obolibrary.org/obo/IDOMAL_0001241` (condition) | publication_comment_needs_review | exclude | exclude | manual_include_status |
| MATERIALSMINE | `http://materialsmine.org/ns/Condition` (Condition) | publication_comment_needs_review | exclude | exclude | manual_include_status |
| MELLO-D | `http://www.semanticweb.org/user/ontologies/2023/10/untitled-ontology-5#condition` (Condition) | publication_comment_needs_review | include | include | manual_include_status |
| OCO | `https://w3id.org/opencare#Condition` (Condition) | publication_comment_needs_review | include | include | manual_include_status |
| YOGA | `https://yogaontology.org/ontology/Condition` (Condition) | publication_comment_needs_review | include | include | manual_include_status |
| ABD | `http://brd.bsvgateway.org/api/disease/` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| AHOL | `http://opendata.inra.fr/AHOL/AHOL_0005001` (disease) | publication_comment_needs_review | include | include | manual_include_status |
| AURA | `http://www.projecthalo.com/aura#Disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| BAO | `http://www.bioassayontology.org/bao#BAO_0002927` (disease) | publication_comment_needs_review | include | include | manual_include_status |
| BPT | `urn:agi-folder:disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| CASE-BASE-ONTO | `http://www.semanticweb.org/hsh/ontologies/2019/7/CBRDystempOnto#Disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| CDPEO | `http://www.semanticweb.org/ontologies/chronic-diease-patient-education-ontology#Disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| CODO | `https://w3id.org/codo#Disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| CONDOR | `http://www.semanticweb.org/erden/ontologies/2023/7/LiverCancerExample/OWLClass_b5ec253b_53ec_4771_82e9_fa3d0d08dd33` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| DCO | `http://www.dispedia.de/o/Disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| ELIG | `http://www.semanticweb.org/ontologies/2012/8/Ontology1348158066194.owl#OWLClass_00000012615273587629` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| EXO | `http://purl.obolibrary.org/obo/ExO_0000079` (disease) | publication_comment_needs_review | include | include | manual_include_status |
| HINO | `http://purl.obolibrary.org/obo/HINO_0015722` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease-1` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease1` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_10` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_11` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_12` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_13` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_2` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_3` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_4` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_5` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_6` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_7` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_8` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IRAEO | `http://example.org/irAEs.owl#Disease_9` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| LOINC | `http://purl.bioontology.org/ontology/LNC/LA18199-2` (Disease) | publication_comment_needs_review | exclude | exclude | manual_include_status |
| MEPO | `http://www.case.edu/EpSO.owl#Disease` (Disease) | eligibility_unresolved |  | needs_user_decision | manual_status_missing |
| MEPO | `http://www.semanticweb.org/rjyy/ontologies/2015/5/ESSO#disease` (disease) | eligibility_unresolved |  | needs_user_decision | manual_status_missing |
| MI | `http://purl.obolibrary.org/obo/MI_0617` (disease) | publication_comment_needs_review | include | include | manual_include_status |
| OBI | `http://purl.obolibrary.org/obo/OBI_1110055` (disease) | eligibility_manual_rule_conflict | include | needs_user_decision | imported_or_reused_term_no_independent_analysis |
| NIFSTD | `http://uri.neuinfo.org/nif/nifstd/birnlex_11013` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| OCO | `https://w3id.org/opencare#Disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| OMIT | `http://purl.obolibrary.org/obo/OMIT_0005457` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| ONTOAD | `http://doe-generated-ontology.com/OntoAD#C0012634` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| ONTONEPHRO | `http://www.limics.fr/ontologies/ontoDOME#Maladie` (disease) | eligibility_unresolved |  | needs_user_decision | manual_status_missing |
| PMR | `http://purl.bioontology.org/ontology/PMR.owl#Disease` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| IEV | `http://purl.obolibrary.org/obo/IEV_0000075` (Disease) | eligibility_manual_rule_conflict; citation_approval_unreviewed | include | needs_user_decision | imported_or_reused_term_no_independent_analysis |
| TMO | `http://www.w3.org/2001/sw/hcls/ns/transmed/TMO_0047` (disease) | publication_comment_needs_review | include | include | manual_include_status |
| UNIPROT | `http://purl.uniprot.org/core/Disease_Annotation` (Disease) | publication_comment_needs_review | include | include | manual_include_status |
| OGMS | `http://purl.obolibrary.org/obo/OGMS_0000063` (disease course) | eligibility_manual_rule_conflict | include | needs_user_decision | term_out_of_scope_not_disease_synonym |
| ONTOPSYCHIA | `http://www.limics.fr/ontologies/ontopsychiasoc#Trouble` (disorder) | publication_comment_needs_review | include | include | manual_include_status |
| OGMS | `http://purl.obolibrary.org/obo/OGMS_0000045` (disorder) | publication_comment_needs_review | exclude | exclude | manual_include_status |
| SL_DIS | `http://example.org/ontology/Disorder` (Disorder) | publication_comment_needs_review | include | include | manual_include_status |
| NCIT | `http://purl.obolibrary.org/obo/NCIT_C3671` (Injury) | eligibility_manual_rule_conflict | include | needs_user_decision | term_out_of_scope_not_disease_synonym |
| MONDO | `http://purl.obolibrary.org/obo/MONDO_0021178` (injury) | eligibility_manual_rule_conflict | include | needs_user_decision | term_out_of_scope_not_disease_synonym |
| GSSO | `http://purl.obolibrary.org/obo/GSSO_009123` (injury) | eligibility_manual_rule_conflict | include | needs_user_decision | term_out_of_scope_not_disease_synonym |
| HIO | `http://purl.obolibrary.org/obo/HIO_0000093` (Injury) | eligibility_manual_rule_conflict | include | needs_user_decision | term_out_of_scope_not_disease_synonym |
| OGMS | `http://purl.obolibrary.org/obo/OGMS_0000102` (injury) | eligibility_manual_rule_conflict | include | needs_user_decision | term_out_of_scope_not_disease_synonym |
| TRAK | `http://purl.obolibrary.org/obo/TRAK_0000206` (injury) | eligibility_manual_rule_conflict | include | needs_user_decision | term_out_of_scope_not_disease_synonym |
| OBI | `http://purl.obolibrary.org/obo/OBI_1110122` (pathological process) | eligibility_manual_rule_conflict | include | needs_user_decision | imported_or_reused_term_no_independent_analysis |
| MPATH | `http://purl.obolibrary.org/obo/MPATH_0` (pathological entity) | publication_comment_needs_review | include | include | manual_include_status |
| ALLERGIDOC | `https://allergo.infodocs.eu/ontologie/allergidoc3.0/Syndrome` (Syndrome) | publication_comment_needs_review | include | include | manual_include_status |
| NCIT | `http://purl.obolibrary.org/obo/NCIT_C28193` (Syndrome) | eligibility_manual_rule_conflict | include | needs_user_decision | imported_or_reused_term_no_independent_analysis |
| SEPON | `http://www.semanticweb.org/zchero/ontologies/2023/11/SepsisOntology#Syndrome` (Syndrome) | publication_comment_needs_review | include | include | manual_include_status |
| ONTOPNEUMO | `http://doe-generated-ontology.com/OntoPneumo#EtatPathologique` (état pathologique) | publication_comment_needs_review | include | include | manual_include_status |
| RCD | `http://purl.bioontology.org/ontology/RCD/X0003` (Disorders) | publication_comment_needs_review | include | include | manual_include_status |
| SSO | `http://surveillance.mcgill.ca/sso/syndromes.owl#ClinicalCondition` (Clinical Condition) | publication_comment_needs_review | include | include | manual_include_status |
| GSSO | `http://purl.obolibrary.org/obo/GSSO_000484` (health condition) | citation_status_unreviewed; citation_approval_unreviewed | include | include | manual_include_status |
| COID | `https://github.com/sap218/coid/blob/master/coid.owl#COID_00609` (clinical associations) | citation_approval_unreviewed; publication_comment_needs_review | include | include | manual_include_status |
| OSDI | `https://w3id.org/ontologies-ULL/OSDi#HealthCondition` (Health condition) | citation_status_unreviewed; citation_approval_unreviewed | include | include | manual_include_status |

## Remaining Human Tasks

- Independent second reviewer and adjudication remain pending.
- Register or otherwise activate the chosen w3id.org namespace before public release.
- Approve or edit publication-neutral comment proposals and eligibility conflicts in the review UI.
