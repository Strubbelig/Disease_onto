# Disease Ontology Scoping Review Release Candidate

Generated: 2026-08-06T18:38:33-04:00

This package is generated from `data/disease_terms_review_enriched.csv`, the sole editable master table.

## Contents

- `ontology/disease_terms_review.ttl`: all 278 screening/evidence records.
- `ontology/disease_terms_synthesis.ttl`: included-only synthesis view.
- `ontology/review_core.ttl`: review annotation-property declarations.
- `ontology/native_hierarchy_modules/`: subject-sanitized native evidence modules.
- `ontology/catalog-v001.xml`: local persistent-IRI resolution.
- `audit/`: schema, data dictionary, changelog, and readiness report.

## Current Decision State

- Included: 133
- Excluded: 128
- Needs adjudication: 17

This is a release candidate, not the final scholarly release. Independent review, pending eligibility/comment/citation decisions, OSF registration details, and activation of the `w3id.org` namespace remain author tasks.

The package is MIT-licensed as specified in `LICENSE`. Extracted source-ontology statements retain their original provenance and any rights held by their source publishers.
