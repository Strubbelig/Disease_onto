# Publication Readiness Report

Generated: `2026-08-07T17:34:56-04:00`

- Master rows: 278
- Unique class IRIs: 278
- Effective status: `{"exclude": 137, "include": 141}`
- Evidence status: `{"fallback_with_evidence": 13, "insufficient_metadata": 6, "native_module": 259}`
- Ambiguous decisions: 0
- Citation assignments still unreviewed: 0
- Approved citations with incomplete core metadata: 0
- Target/module mismatches: 0
- Cross-module duplicate superclass edges: 0

## Ambiguous Decisions

| Ontology | Class | Flags | Manual | Effective | Rule |
|---|---|---|---|---|---|

## Remaining Human Tasks

- Publish the retrospective OSF registration and insert its DOI, URL, and date in the manuscript.
- Decide whether to add independent validation; the completed first review used one reviewer.
- Complete authorship, contribution, conflict-of-interest, and public repository metadata.
- Register or otherwise activate the chosen w3id.org namespace before public release.
