# Disease Ontology Scoping Review Release Candidate

Generated: 2026-08-07T17:34:56-04:00

This package is generated from `data/disease_terms_review_enriched.csv`, the sole editable master table.

## Contents

- `ontology/disease_terms_review.ttl`: all 278 screening/evidence records.
- `ontology/disease_terms_synthesis.ttl`: included-only synthesis view.
- `ontology/review_core.ttl`: review annotation-property declarations.
- `ontology/native_hierarchy_modules/`: subject-sanitized native evidence modules.
- `ontology/catalog-v001.xml`: local persistent-IRI resolution.
- `audit/`: schema, data dictionary, changelog, and readiness report.
- `figures/`: final PRISMA-ScR flow diagram in PNG and SVG formats.
- `docs/OSF_Retrospective_Registration_Addendum.md`: implemented-methods record for retrospective OSF registration.

## Current Decision State

- Included: 141
- Excluded: 137
- Needs adjudication: 0

This is a release candidate, not the final scholarly release. The first-review eligibility, coding, wording, and citation decisions are complete. Retrospective OSF registration, authorship and disclosure metadata, a public repository DOI, the decision on optional independent validation, and activation of the `w3id.org` namespace remain author tasks. A broader philosophical-literature synthesis is a separate project and is not part of this artifact-review denominator.

The package is MIT-licensed as specified in `LICENSE`. Extracted source-ontology statements retain their original provenance and any rights held by their source publishers.
