# Retrospective Registration Addendum

## Review title

How Is Disease Formally Modelled in Biomedical Ontologies? A Scoping Review of Ontology Artifacts

## Registration timing and status

This registration is retrospective. Ontology retrieval, class-level screening, charting, and the first-review synthesis were complete before public registration. The registration must not be described as a preregistration or as prospective. It freezes the implemented methods and records deviations from the earlier draft protocol.

## Implemented review scope

The completed study is an ontology-artifact scoping review. Its evidence units are OWL/RDFS classes identified by IRI and retrieved from BioPortal, the EBI Ontology Lookup Service, the OBO Foundry, or targeted artifact retrieval. Publications are supporting evidence for interpreting or citing an ontology; they are not independently screened study records. A broader philosophical-literature synthesis is a separate project.

## Implemented information sources and dates

- BioPortal API, primary source: 29 June to 6 July 2026.
- EBI Ontology Lookup Service v4: 29 June to 4 July 2026.
- OBO Foundry registry and direct active-product scan: 29 June 2026.
- Targeted GitHub or ontology-site retrieval for known artifacts or replacement classes, recorded in row-level provenance.

## Implemented unit of analysis and de-duplication

The unit of analysis is a class IRI together with available labels, definitions, comments, synonyms, asserted named superclass hierarchy, mappings, source metadata, and any supporting modelling citation. Source-ontology appearances were merged by exact class IRI. The review does not claim complete extraction of anonymous restrictions or imported logical axioms.

## Implemented selection and charting

Automated screens addressed provenance, source type, term scope, target refinement, semantic equivalence, and imported/reused appearances. One reviewer then assessed and charted all 278 unique class-level records using a structured review interface. Screening and charting were not performed independently or in duplicate, and no agreement statistic was calculated. All records received a final first-review inclusion or exclusion decision.

## Implemented synthesis

The synthesis used descriptive counts, percentages, selected group means, a narrative disease-model typology, dependency/reuse analysis, evidence-quality summaries, and a gap map across ontological category, pathological grounding, crispness/gradedness, and reality/classification. No meta-analysis or clinical risk-of-bias assessment was performed.

## Deviations from the earlier draft protocol

1. The planned bibliographic-database and proceedings review was not incorporated into the artifact denominator; it is reserved for a separate project.
2. Screening and charting were performed by one reviewer rather than two reviewers in duplicate.
3. The completed registry set was BioPortal, OLS, and OBO Foundry; AberOWL was not searched.
4. The search strategy was implemented as normalized exact-label API retrieval with primary, secondary, compound-label, and French/German sensitivity tiers.
5. Rule-based provenance and reuse screens were added to distinguish independent disease models from mappings and imported appearances.
6. The evidence model was limited to retrievable class annotations and asserted named superclass hierarchy rather than complete logical-axiom extraction.
7. A class-level entity-quality appraisal and citation-assignment review were added.

## Completed first-review flow

- Source-ontology appearances identified: 504.
- Appearances excluded by automated screening: 222.
- Candidate appearances retained: 282.
- Unique class IRIs after de-duplication: 278.
- Included in synthesis: 141.
- Excluded after class-level review: 137.
- Unresolved first-review decisions: 0.

## Files to freeze with the registration

- `Scoping_Review_Protocol_Disease_Modelling.md`: earlier draft protocol.
- `OSF_Retrospective_Registration_Addendum.md`: this implemented-methods addendum.
- `Scoping_Review_Manuscript.md`: current PRISMA-ScR manuscript draft.
- `disease_terms_review_enriched.csv`: sole class-level master table.
- `disease_terms_review.ttl` and `disease_terms_synthesis.ttl`: generated evidence and synthesis views.
- `prisma_scr_flow_diagram.png`: flow diagram.
- The dated release archive and its manifest.

## Registration fields to complete manually

- Authors, affiliations, and ORCID identifiers.
- OSF project title and description.
- Conflicts of interest and funding.
- Public registration date, URL, and DOI.
- Optional embargo decision. Public release is preferable when the manuscript is submitted so the protocol is accessible to reviewers.
